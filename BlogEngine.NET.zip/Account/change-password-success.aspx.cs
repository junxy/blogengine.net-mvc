﻿namespace Account
{
    using System.Web.UI;

    /// <summary>
    /// The change password success.
    /// </summary>
    public partial class ChangePasswordSuccess : Page
    {
    }
}